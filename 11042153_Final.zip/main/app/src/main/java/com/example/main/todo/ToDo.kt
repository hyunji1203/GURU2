package com.example.main.todo

class ToDo(

    var id : Long = -1,
    var name : String = "",
    var createdAt : String = "",

    var isChecked: Boolean = false
)
