package com.example.main

class profiles2 (val name: String, val period: String, val explain: String, val type: String, var ring : Int, var star : Int, var day2: String, var value : Int, var bool : Int, var star_x: Int, var typenum : Int ) {
}