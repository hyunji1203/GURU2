package com.example.main.search

// 데이터 베이스에서 불러올 변수명
data class scholarship(var name : String? = null, var cost : Int? = null)
