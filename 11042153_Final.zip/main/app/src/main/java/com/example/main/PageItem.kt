package com.jeongdaeri.introslideproject

class PageItem(val bgColor: Int, val imageSrc: Int, val content: String) {
}
